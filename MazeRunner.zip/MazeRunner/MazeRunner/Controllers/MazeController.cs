﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MazeRunner.Controllers
{
    public class MazeController : ApiController
    {
        [HttpPost]
        public IHttpActionResult solveMaze([FromBody] string map)
        {
            string[] lines = map.Split(new[] { "\n" }, StringSplitOptions.None);

            int width = lines[0].Length;
            int height = lines.Count();

            var UnVistited = new List<Tile>();

            Tile[,] Maze = new Tile[width, height];

            int startX = 0;
            int startY = 0;

            int endX = 0;
            int endY = 0;

            int index = 1;

            int x;
            int y = 0;
            foreach (string line in lines)
            {
                x = 0;
                foreach (var c in line.ToArray())
                {
                    var t = new Tile();
                    t.Type = c;
                    t.Distance = 1000000;
                    t.X = x;
                    t.Y = y;

                    if (c == 'A')
                    {
                        t.Distance = 0;
                        startX = x;
                        startY = y;
                    }

                    else if (c == 'B')
                    {
                        t.Index = 1000000;
                        endX = x;
                        endY = y;
                        UnVistited.Add(t);
                    }

                    else if (c == '#')
                    {
                        t.Distance = -1;
                        t.Index = -1;
                    }
                    else
                    {
                        t.Index = index++;
                        UnVistited.Add(t);
                    }

                    Maze[x, y] = t;
                    x++;
                }
                y++;

            }

            int CurrX = startX;
            int CurrY = startY;

            while (UnVistited.Count > 0)
            {
                //look N, currY-1
                if (CurrY > 0)
                {
                    if (Maze[CurrX, CurrY - 1].Type == '.' || Maze[CurrX, CurrY - 1].Type == 'B')
                    {
                        if (Maze[CurrX, CurrY].Distance + 1 < Maze[CurrX, CurrY - 1].Distance)
                        {
                            Maze[CurrX, CurrY - 1].Distance = Maze[CurrX, CurrY].Distance + 1;
                            Maze[CurrX, CurrY - 1].Previous = Maze[CurrX, CurrY];
                        }

                    }
                }


                //look E, currX+1
                if (CurrX < width - 1)
                {
                    if (Maze[CurrX + 1, CurrY].Type == '.' || Maze[CurrX + 1, CurrY].Type == 'B')
                    {
                        if (Maze[CurrX, CurrY].Distance + 1 < Maze[CurrX + 1, CurrY].Distance)
                        {
                            Maze[CurrX + 1, CurrY].Distance = Maze[CurrX, CurrY].Distance + 1;
                            Maze[CurrX + 1, CurrY].Previous = Maze[CurrX, CurrY];
                        }

                    }
                }


                //look S, currY+1
                if (CurrY < height - 1)
                {
                    if (Maze[CurrX, CurrY + 1].Type == '.' || Maze[CurrX, CurrY + 1].Type == 'B')
                    {
                        if (Maze[CurrX, CurrY].Distance + 1 < Maze[CurrX, CurrY + 1].Distance)
                        {
                            Maze[CurrX, CurrY + 1].Distance = Maze[CurrX, CurrY].Distance + 1;
                            Maze[CurrX, CurrY + 1].Previous = Maze[CurrX, CurrY];
                        }

                    }
                }


                //look W, currX-1
                if (CurrX > 0)
                {
                    if (Maze[CurrX - 1, CurrY].Type == '.' || Maze[CurrX - 1, CurrY].Type == 'B')
                    {
                        if (Maze[CurrX, CurrY].Distance + 1 < Maze[CurrX - 1, CurrY].Distance)
                        {
                            Maze[CurrX - 1, CurrY].Distance = Maze[CurrX, CurrY].Distance + 1;
                            Maze[CurrX - 1, CurrY].Previous = Maze[CurrX, CurrY];
                        }

                    }
                }

                var Closest = UnVistited.OrderBy(n => n.Distance).FirstOrDefault();

                CurrX = Closest.X;
                CurrY = Closest.Y;

                UnVistited.Remove(Closest);
            }


            CurrX = endX;
            CurrY = endY;

            int NumberOfSteps = 0;

            while (CurrX != startX || CurrY != startY)
            {
                var prev = Maze[CurrX, CurrY].Previous;
                prev.Type = '@';
                CurrX = prev.X;
                CurrY = prev.Y;
                NumberOfSteps++;
            }

            var Return = new Maze();
            Return.steps = NumberOfSteps;

            string m = "";
            for (y = 0; y < height; y++)
            {
                for (x = 0; x < width; x++)
                    m += Maze[x, y].Type;

                m += Environment.NewLine;
            }

            Return.solution = m;

            return Json(Return);
        }
    }
}
