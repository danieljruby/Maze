﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MazeRunner
{
    public class Maze
    {
        public string solution { get; set; }
        public int steps { get; set; }
    }

    public class Tile
    {
        public char Type { get; set; }
        public int Distance { get; set; }
        public int Index { get; set; }
        public Tile Previous { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
    }
}